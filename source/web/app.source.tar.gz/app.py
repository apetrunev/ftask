from flask import Flask, g, jsonify
import psycopg2

app = Flask(__name__)

def connectToDb():
    try:
        return psycopg2.connect(dbname="ms_db", user="ms_admin", password="123", host="192.168.58.3")
    except:
        print("Can't connect to database")


@app.route("/")
def hello():
    return "<a href='/authors'>Authors</a><br>" \
           "<a href='/magazines'>Magazines</a><br>" \
           "<a href='/article_types'>Article types</a>"

@app.route("/authors")
def show_authors():
    conn = connectToDb()
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM author")
    records = cursor.fetchall()
    conn.commit()

    items = []
    for rec in records:
        item = ''.join(rec)
        items.append(item)
    res = '<br>'.join(items)
    return res

@app.route("/magazines")
def show_magazines():
    conn = connectToDb()
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM magazines")
    records = cursor.fetchall()
    conn.commit()

    items = []
    for rec in records:
        item = ''.join(rec)
        items.append(item)
    res = '<br>'.join(items)
    return res

@app.route("/article_types")
def show_article_types():
    conn = connectToDb()
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM article_types")
    records = cursor.fetchall()
    conn.commit()

    items = []
    for rec in records:
        item = ''.join(rec)
        items.append(item)
    res = '<br>'.join(items)
    return res

if __name__ == "__main__":
    app.run(host='0.0.0.0')
